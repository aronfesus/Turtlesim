def main():
    print('Hi from ros2_course.')


if __name__ == '__main__':
    main()
