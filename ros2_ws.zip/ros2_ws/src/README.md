# Turtlesim

## Installation

### Clone the Repository:

cd ~/ros2_ws/src  
git clone https://github.com/aronfesus/Turtlesim.git

### Build the Package:

cd ~/ros2_ws  
colcon build --packages-select ros2_course

### Source the Environment:

. install/setup.bash

## Usage
ros2 launch ros2_course turtlesim_launch.py

